import fs from 'node:fs';
import { chromium, expect } from '@playwright/test';
import * as pictures from '../../../tests/e2e/still-picture.ts';
import * as state from '../../../packages/explorer/src/client/persistence/compressed-url-state.ts';
const out='AI-Agent-Workspace/tmp/2026-11-10-reading-focus/native';
fs.mkdirSync(out,{recursive:true});
const browser=await chromium.launch({headless:true});
const subjects=[{name:'repository',id:'packages/explorer/src/client/views/symbolAnchors.ts',first:'normalizeSymbolIdentifier',second:'buildNormalizedAnchorKey',root:'http://127.0.0.1:8900/'},{name:'estate',id:'PaymentService/PaymentService.cs',first:'PaymentService',root:'http://127.0.0.1:8900/samples/estate/'}];
const result={readings:[],errors:[]};
try{for(const item of subjects)for(const mode of ['slot','grow']){
 const prefix=`${item.name}-${mode}`,context=await browser.newContext({viewport:{width:1440,height:960},deviceScaleFactor:1,recordVideo:{dir:`${out}/motion`,size:{width:1440,height:960}}});
 const page=await context.newPage();page.on('pageerror',error=>result.errors.push({prefix,error:String(error)}));
 const snapshot={...state.DEFAULT_SNAPSHOT,view:'map',perspective:'2d',selectedNodeId:item.id,pinSet:{entries:[{nodeId:item.id,symbol:'*'}]},reading:[{nodeId:item.id,open:true}]};
 await page.goto(`${item.root}?s=${state.compressSnapshot(snapshot)}`);
 await pictures.localMapStill(page);
 await page.getByText('Tuning',{exact:true}).click();
 await page.locator('#tuning-card-text').selectOption(mode);
 await page.getByText('Tuning',{exact:true}).click();
 await pictures.localMapStill(page);
 const card=page.locator(`.node-card[data-id="${item.id}"]`);
 const book=symbol=>symbol?card.locator(`.symbol-row[data-symbol="${symbol}"] .local-symbol-read`):card.locator('.local-file-read');
 const capture=async(name,screenshot=true)=>{
  const reading=await card.evaluate((element,{id,name,mode})=>{
   const box=e=>{const b=e.getBoundingClientRect();return{x:b.x,y:b.y,width:b.width,height:b.height};};
   const root=document.querySelector('#map-container .local-placed');
   return{id,name,mode,card:box(element),title:box(element.querySelector('button')),rows:[...element.querySelectorAll('.symbol-row')].map(row=>({symbol:row.dataset.symbol,box:box(row),name:box(row.querySelector('button')??row),paragraphs:[...row.querySelectorAll('.local-reading-prose')].map(p=>({text:p.textContent,box:box(p),font:getComputedStyle(p).fontSize,display:getComputedStyle(p).display,visibility:getComputedStyle(p).visibility})),book:row.querySelector('.local-symbol-read')?.getAttribute('aria-expanded')})),search:root?{...root.dataset}:null};
  },{id:item.id,name,mode});
  const snap=state.decompressSnapshot(new URL(page.url()).searchParams.get('s'));
  result.readings.push({...reading,subject:item.name,url:page.url(),pins:snap.pinSet,reading:snap.reading,selected:snap.selectedNodeId});
  if(screenshot)await page.screenshot({path:`${out}/${prefix}-${name}.png`});
  console.log(JSON.stringify({prefix,name,card:reading.card,open:reading.rows.filter(r=>r.book==='true').map(r=>r.symbol)}));
 };
 const press=async(symbol,name)=>{const control=book(symbol);await pictures.panIntoView(page,control);await pictures.localMapStill(page);await capture(`${name}-before`,false);await control.click();await pictures.localMapStill(page);await capture(name);};
 await capture('all');
 await press(null,'none');
 await press(item.first,'one');
 if(item.second){await press(item.second,'two');await press(item.first,'second-only');}
 await press(null,'all-again');
 const video=page.video();await context.close();await video.saveAs(`${out}/${prefix}-journey.webm`);
 fs.writeFileSync(`${out}/observations.json`,JSON.stringify(result,null,2)+'\n');
}}
finally{await browser.close();fs.writeFileSync(`${out}/observations.json`,JSON.stringify(result,null,2)+'\n');}
