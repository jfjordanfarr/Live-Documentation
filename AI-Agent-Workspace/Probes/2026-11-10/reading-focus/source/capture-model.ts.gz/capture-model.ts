import fs from "node:fs/promises";
import path from "node:path";
import { createHash } from "node:crypto";
import { chromium } from "@playwright/test";

import { captureFromPage, writeCapture } from "./trial-worktree/scripts/layout-lab/capture";
import { cardMetrics } from "./trial-worktree/scripts/layout-lab/card-model";
import { cardViews } from "./trial-worktree/scripts/layout-lab/measurer";
import { includeNode } from "./trial-worktree/scripts/layout-lab/evaluate";
import { admitCompiledFunctions, type ScopeRun } from "./trial-worktree/scripts/layout-lab/scopes";
import { explorerGraphOf } from "./trial-worktree/packages/explorer/src/shared/graph";
import { getDefaultTuning } from "./trial-worktree/packages/explorer/src/client/persistence/local-storage";
import { compressSnapshot, decompressSnapshot, DEFAULT_SNAPSHOT } from "./trial-worktree/packages/explorer/src/client/persistence/compressed-url-state";
import { buildBranches } from "./trial-worktree/packages/explorer/src/client/views/localView/branches";
import { localMapStill } from "./trial-worktree/tests/e2e/still-picture";

const home = "/workspaces/Live-Documentation/AI-Agent-Workspace/tmp/2026-11-10-reading-focus";
const worktree = path.join(home, "trial-worktree");
const out = path.join(home, "capture-model");
const origin = "http://127.0.0.1:8918";
const subjects = [
  { bundle: "repository" as const, base: "/", id: "packages/explorer/src/client/views/symbolAnchors.ts", symbol: "normalizeSymbolIdentifier" },
  { bundle: "estate" as const, base: "/samples/estate/", id: "PaymentService/PaymentService.cs", symbol: "PaymentService" }
];
const json = (file: string, value: unknown) => fs.writeFile(path.join(out, file), JSON.stringify(value, null, 2) + "\n");
const hash = async (file: string) => createHash("sha256").update(await fs.readFile(file)).digest("hex");

async function main(): Promise<void> {
  await fs.mkdir(out, { recursive: true });
  const manifest = JSON.parse(await fs.readFile(path.join(home, "trial-manifest.json"), "utf8"));
  const frozen = async () => Object.fromEntries(await Promise.all(Object.keys({ ...manifest.sourceFiles, ...manifest.assets }).map(async file => [file, await hash(path.join(worktree, file))])));
  const initialHashes = await frozen();
  const startedAt = new Date().toISOString();
  const summary: { startedAt: string; cases: unknown[]; errors: unknown[]; endedAt?: string; hashesUnchanged?: boolean } = { startedAt, cases: [], errors: [] };
  const browser = await chromium.launch({ headless: true });
  try {
    for (const subject of subjects) {
      const started = performance.now();
      const context = await browser.newContext({ viewport: { width: 1440, height: 960 }, deviceScaleFactor: 1 });
      const page = await context.newPage();
      const pageErrors: string[] = [];
      page.on("pageerror", error => pageErrors.push(String(error)));
      try {
        const pinSet = { entries: [{ nodeId: subject.id, symbol: "*" }] };
        const reading = [{ nodeId: subject.id, open: false }, { nodeId: subject.id, symbol: subject.symbol, open: true }];
        const snapshot = { ...DEFAULT_SNAPSHOT, view: "map" as const, perspective: "2d" as const, selectedNodeId: subject.id, pinSet, reading };
        const url = `${origin}${subject.base}?s=${compressSnapshot(snapshot)}`;
        await page.goto(url);
        await admitCompiledFunctions(page);
        await page.mouse.move(20, 20);
        await localMapStill(page);
        const readDOM = () => page.evaluate(() => {
          const map = document.querySelector<HTMLElement>("#map-container")!;
          const root = map.querySelector<HTMLElement>(".local-placed")!;
          return {
            lod: map.dataset.lod, step: map.dataset.step, search: { ...root.dataset },
            tuning: Object.fromEntries(["tuning-card-text", "tuning-search-starts", "tuning-move-ms"].map(id => [id, (document.getElementById(id) as HTMLInputElement).value])),
            cards: Object.fromEntries([...root.querySelectorAll<HTMLElement>(".node-card")].map(card => [card.dataset.id!, {
              width: card.offsetWidth, height: card.offsetHeight,
              rows: [...card.querySelectorAll<HTMLElement>(".symbol-row")].map(row => ({
                symbol: row.dataset.symbol!, shown: row.getClientRects().length > 0, width: row.offsetWidth, height: row.offsetHeight,
                folded: row.classList.contains("local-slot-folded"), measuredHead: row.style.getPropertyValue("--slot-head-h"),
                descriptionHidden: row.querySelector<HTMLElement>(".local-reading-block")?.hidden,
                descriptionOpen: row.querySelector<HTMLElement>(".local-reading-block")?.dataset.readingOpen
              }))
            }]))
          };
        });
        const before = await readDOM();
        await json(`${subject.bundle}-dom-before.json`, { url: page.url(), state: decompressSnapshot(new URL(page.url()).searchParams.get("s")!), ...before });
        if (before.tuning["tuning-card-text"] !== "slot" || before.tuning["tuning-search-starts"] !== "32" || before.tuning["tuning-move-ms"] !== "450") throw new Error("The page did not retain its ordinary slot/search/motion defaults.");
        const run: ScopeRun = { bundle: subject.bundle, base: subject.base, scopeName: "one-open slot trial", scope: [subject.id], subject: subject.id };
        const capture = await captureFromPage(page, run);
        await writeCapture(capture, path.join(out, `${subject.bundle}-capture.json`));
        const after = await readDOM();
        await json(`${subject.bundle}-dom-after.json`, after);
        const data = JSON.parse(await fs.readFile(path.join(worktree, "dist/explorer", subject.base, "explorer-data.json"), "utf8"));
        const graph = explorerGraphOf(data.graph);
        const tuning = getDefaultTuning().localMap;
        const center = graph.nodes.find(node => node.id === subject.id)!;
        const branches = buildBranches(center, graph, pinSet, includeNode(pinSet, subject.id, capture.filters), {
          symbolOrder: tuning.symbolOrder, ranking: { pull: tuning.rankingPull, tie: tuning.rankingTie }, reading,
          membraneDepth: tuning.membraneDepth
        });
        // Preserve the browser's learned order. The comparison predicts card boxes/ports, not a new layout search.
        const actualOrder = { ...branches, rows: new Map(Object.entries(capture.cards).map(([id, card]) => [id, card.rows.map(row => row.symbol)])) };
        const views = cardViews(capture, actualOrder, { pins: pinSet, selected: subject.id, collapseOnPin: tuning.collapseOnPin, symbolOrder: tuning.symbolOrder });
        const comparisons = [];
        for (const [id, card] of Object.entries(capture.cards)) {
          const view = views.get(id)!;
          const modeled = cardMetrics(capture, card, card.truth.width, view);
          const ports = Object.entries(card.truth.pins).map(([key, actual]) => {
            const value = modeled.pins.get(key);
            const predicted = value === undefined ? null : Math.round(value + 1e-3);
            return { key, actual, predicted, unrounded: value ?? null, equal: predicted === actual };
          });
          const visibleDOM = before.cards[id].rows.filter(row => row.shown).map(row => row.symbol);
          const visibleModel = view.rows.map(row => row.symbol);
          comparisons.push({ id, browser: card.truth, modeled: { width: modeled.width, height: modeled.height, roundedHeight: Math.round(modeled.height), pins: Object.fromEntries(modeled.pins) },
            equalHeight: Math.round(modeled.height) === card.truth.height,
            equalRowScopeAndOrder: JSON.stringify(visibleDOM) === JSON.stringify(visibleModel), visibleDOM, visibleModel,
            foldedRows: card.rows.filter(row => row.slotFolded).map(row => row.symbol), ports });
        }
        const result = {
          bundle: subject.bundle, subject: subject.id, symbol: subject.symbol, url, elapsedMs: performance.now() - started,
          captureWarnings: capture.warnings, pageErrors,
          capturePreservedDOMGeometry: JSON.stringify(before.cards) === JSON.stringify(after.cards),
          capturePreservedSearch: JSON.stringify(before.search) === JSON.stringify(after.search),
          comparisons,
          counts: { cards: comparisons.length, heightMismatches: comparisons.filter(card => !card.equalHeight).length,
            rowScopeMismatches: comparisons.filter(card => !card.equalRowScopeAndOrder).length,
            ports: comparisons.reduce((sum, card) => sum + card.ports.length, 0), portMismatches: comparisons.reduce((sum, card) => sum + card.ports.filter(port => !port.equal).length, 0) }
        };
        await json(`${subject.bundle}-comparison.json`, result);
        summary.cases.push({ bundle: result.bundle, elapsedMs: result.elapsedMs, counts: result.counts, captureWarnings: result.captureWarnings,
          pageErrors, capturePreservedDOMGeometry: result.capturePreservedDOMGeometry, capturePreservedSearch: result.capturePreservedSearch });
        console.log(JSON.stringify(summary.cases.at(-1)));
      } catch (error) {
        const failure = { bundle: subject.bundle, error: String(error), stack: (error as Error).stack, pageErrors };
        summary.errors.push(failure);
        await json(`${subject.bundle}-error.json`, failure);
        console.error(JSON.stringify(failure));
      } finally {
        await context.close();
        await json("summary.json", summary);
      }
    }
  } finally {
    await browser.close();
    summary.endedAt = new Date().toISOString();
    const finalHashes = await frozen();
    summary.hashesUnchanged = JSON.stringify(initialHashes) === JSON.stringify(finalHashes);
    await json("source-and-asset-hashes.json", { initialHashes, finalHashes, unchanged: summary.hashesUnchanged });
    await json("summary.json", summary);
  }
  if (summary.errors.length || !summary.hashesUnchanged) process.exitCode = 1;
}

main().catch(error => { console.error(error); process.exitCode = 1; });
