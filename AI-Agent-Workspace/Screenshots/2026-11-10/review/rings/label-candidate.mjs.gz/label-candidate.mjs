import fs from 'node:fs';
import { chromium, expect } from '@playwright/test';
import { observeGraph, renderedNodes } from '../../../tests/e2e/force-graph-observation.ts';
import { localMapSettled } from '../../../tests/e2e/still-picture.ts';
import { decompressSnapshot } from '../../../packages/explorer/src/client/persistence/compressed-url-state.ts';

const out='AI-Agent-Workspace/tmp/2026-11-10-rings/label-candidate';
fs.mkdirSync(out,{recursive:true});
const browser=await chromium.launch({headless:true}), readings=[],errors=[];
for(const [variant,port] of [['before',8900],['after',8915]]){
 const context=await browser.newContext({viewport:{width:1440,height:960},deviceScaleFactor:1,recordVideo:{dir:out+'/motion',size:{width:1440,height:960}}});
 const page=await context.newPage();page.on('pageerror',e=>errors.push({variant,error:String(e)}));
 await observeGraph(page);
 const settled=()=>expect(page.locator('#graph-svg')).toHaveAttribute('aria-busy','false',{timeout:60000});
 const capture=async(name)=>{
  await page.mouse.move(300,900);await page.waitForTimeout(200);
  const nodes=await renderedNodes(page);
  const drawing=await page.evaluate(()=>{
   const graph=window.renderedGraph, ringMarks=[],wrappers=[];
   graph.scene.traverse(object=>{
    if(object.name==='Spatial wrappers')wrappers.push(...(object.userData.spatialWrappers?.seeds??[]));
    const batch=object.userData.spatialBatch;
    if(batch?.kind==='rings')for(const entry of batch.entries){
     if(!entry.enabled||entry.slot>=object.count)continue;
     const drawn=window.drawnInstance(object,entry),p=drawn.center.clone().project(graph.camera);
     const rect=document.querySelector('#graph-svg canvas').getBoundingClientRect(),right=graph.camera.matrixWorld.elements;
     const rim=drawn.center.clone().add(drawn.center.clone().set(right[0],right[1],right[2]).multiplyScalar(drawn.radius)).project(graph.camera);
     ringMarks.push({id:entry.data.id,x:rect.left+(p.x+1)*rect.width/2,y:rect.top+(1-p.y)*rect.height/2,r:Math.abs(rim.x-p.x)*rect.width/2});
    }
   });
   const labels=[...document.querySelectorAll('.force-graph-label')].filter(e=>!e.hidden).map(e=>{
    const b=e.getBoundingClientRect();return {id:e.dataset.nodeId??'popped:'+e.dataset.directory,text:e.textContent,title:e.title,priority:Number(e.dataset.priority??4),kind:e.dataset.kind,box:{x:b.x,y:b.y,width:b.width,height:b.height}};
   });
   return {ringMarks,wrappers,labels};
  });
  const snapshot=decompressSnapshot(new URL(page.url()).searchParams.get('s'));
  const clearance=(box,ring)=>Math.hypot(Math.max(box.x,Math.min(ring.x,box.x+box.width))-ring.x,Math.max(box.y,Math.min(ring.y,box.y+box.height))-ring.y)-ring.r;
  const overlaps=drawing.labels.flatMap(label=>drawing.ringMarks.filter(r=>r.id!==label.id).map(ring=>({label:label.id,ring:ring.id,clearance:clearance(label.box,ring)}))).filter(x=>x.clearance<2);
  const reading={variant,name,url:page.url(),openDirectories:[...snapshot.openDirectories],pins:snapshot.pinSet.entries,nodes,...drawing,overlaps};readings.push(reading);
  await page.screenshot({path:`${out}/${variant}-${name}.png`});
  fs.writeFileSync(`${out}/readings.json`,JSON.stringify({readings,errors},null,2)+'\n');
  console.log(JSON.stringify({variant,name,labelCount:drawing.labels.length,labels:drawing.labels.map(l=>l.text),overlaps}));
  return reading;
 };
 const switchTo=async name=>{
  const begun=page.locator('.perspective-transition').waitFor({state:'visible',timeout:30000});
  await page.getByRole('button',{name,exact:true}).click();await begun;
  await expect(page.locator('.perspective-transition')).toHaveCount(0,{timeout:60000});
  if(name==='2D')await localMapSettled(page,60000);else await settled();
 };
 try{
  await page.goto(`http://localhost:${port}/samples/estate/?view=local&mode=3d&layout=structure`);await settled();await capture('structure-start');
  await page.locator('.force-graph-label').filter({hasText:/^PaymentService ·/}).click();await settled();await capture('structure-open');
  await switchTo('2D');await switchTo('3D');await capture('structure-return');
  await page.getByRole('button',{name:'Connections',exact:true}).click();await settled();
  const ending=await capture('connections-ending');
  for(const name of ['Hub','Gateway']){
   const target=ending.labels.find(l=>l.text.startsWith(name+' ·'));
   await page.locator(`.force-graph-label[data-node-id="${target.id}"]`).hover();await page.waitForTimeout(250);
   await page.screenshot({path:`${out}/${variant}-hover-${name}.png`});
  }
  await page.goto(`http://localhost:${port}/?view=local&mode=3d&layout=structure`);await settled();await capture('main-structure-start');
 }finally{
  const video=page.video();await context.close();await video.saveAs(`${out}/${variant}-journey.webm`);
 }
}
await browser.close();
const comparisons=readings.filter(r=>r.variant==='before').map(before=>{
 const after=readings.find(r=>r.variant==='after'&&r.name===before.name);
 return {name:before.name,before:before.labels.length,after:after.labels.length,lost:before.labels.filter(l=>!after.labels.some(a=>a.id===l.id)).map(l=>({id:l.id,text:l.text,priority:l.priority})),gained:after.labels.filter(l=>!before.labels.some(b=>b.id===l.id)).map(l=>({id:l.id,text:l.text,priority:l.priority})),beforeOverlaps:before.overlaps,afterOverlaps:after.overlaps};
});
fs.writeFileSync(`${out}/comparison.json`,JSON.stringify({errors,comparisons},null,2)+'\n');console.log(JSON.stringify({errors,comparisons}));
