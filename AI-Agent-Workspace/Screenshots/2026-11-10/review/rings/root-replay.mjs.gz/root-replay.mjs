import fs from 'node:fs';
import { chromium, expect } from '@playwright/test';
import * as observation from '../../../tests/e2e/force-graph-observation.ts';
import * as pictures from '../../../tests/e2e/still-picture.ts';
import * as state from '../../../packages/explorer/src/client/persistence/compressed-url-state.ts';

const out='AI-Agent-Workspace/tmp/2026-11-10-rings/root-candidate';
fs.mkdirSync(out,{recursive:true});
const browser=await chromium.launch({headless:true});
const context=await browser.newContext({viewport:{width:1440,height:960},deviceScaleFactor:1});
const page=await context.newPage(),errors=[],readings=[];
page.on('pageerror',e=>errors.push(String(e)));
await observation.observeGraph(page);
const settled=()=>expect(page.locator('#graph-svg')).toHaveAttribute('aria-busy','false',{timeout:60000});
const capture=async(name,screenshot=true)=>{
  await page.mouse.move(300,900);
  await page.waitForTimeout(200);
  const nodes=await observation.renderedNodes(page);
  const drawn=await page.evaluate(()=>{
    const wrappers=[],units=[],ringMarks=[];
    window.renderedGraph.scene.traverse(object=>{
      if(object.name==='Spatial wrappers')wrappers.push(...(object.userData.spatialWrappers?.seeds??[]));
      if(object.name==='Spatial shell files'&&object.visible)units.push(...(object.userData.spatialUnits??[]).map(u=>({seed:u.seed,id:u.id})));
      const batch=object.userData.spatialBatch;
      if(batch?.kind==='rings')for(const entry of batch.entries){
        if(!entry.enabled)continue;
        const d=window.drawnInstance(object,entry), p=d.center.clone().project(window.renderedGraph.camera);
        const rect=document.querySelector('#graph-svg canvas').getBoundingClientRect();
        const right=window.renderedGraph.camera.matrixWorld.elements;
        const rim=d.center.clone().add(d.center.clone().set(right[0],right[1],right[2]).multiplyScalar(d.radius)).project(window.renderedGraph.camera);
        ringMarks.push({id:entry.data.id,x:rect.left+(p.x+1)*rect.width/2,y:rect.top+(1-p.y)*rect.height/2,r:Math.abs(rim.x-p.x)*rect.width/2});
      }
    });
    const labels=[...document.querySelectorAll('.force-graph-label')].filter(e=>!e.hidden).map(e=>{
      const b=e.getBoundingClientRect();return {id:e.dataset.nodeId,text:e.textContent,title:e.title,kind:e.dataset.kind,context:e.dataset.context,box:{x:b.x,y:b.y,w:b.width,h:b.height}};
    });
    return {wrappers,units,ringMarks,labels};
  });
  const snapshot=state.decompressSnapshot(new URL(page.url()).searchParams.get('s'));
  const reading={name,url:page.url(),layout:snapshot.spatialLayout,openDirectories:[...snapshot.openDirectories],pins:snapshot.pinSet.entries,nodes,...drawn};
  readings.push(reading);
  if(screenshot)await page.screenshot({path:`${out}/${name}.png`});
  console.log(JSON.stringify({name,layout:reading.layout,open:reading.openDirectories,rings:nodes.filter(n=>n.ring).map(n=>n.id),wrappers:drawn.wrappers,labels:drawn.labels.filter(l=>/Hub|Gateway|PaymentQuery|PaymentRequest/.test(l.text))}));
  return reading;
};
const switchTo=async name=>{
  const begun=page.locator('.perspective-transition').waitFor({state:'visible',timeout:30000});
  await page.getByRole('button',{name,exact:true}).click();await begun;
  await expect(page.locator('.perspective-transition')).toHaveCount(0,{timeout:60000});
  if(name==='2D')await pictures.localMapSettled(page,60000);else await settled();
};
try{
  await page.goto('http://localhost:8915/samples/estate/?view=local&mode=3d&layout=structure');
  await settled();const before=await capture('structure-before');
  await page.locator('.force-graph-label').filter({hasText:/^PaymentService ·/}).click();
  await expect.poll(()=>page.url()).not.toBe(before.url);await settled();
  await capture('structure-open');
  await page.getByRole('button',{name:'Show pins',exact:true}).click();
  await page.getByRole('button',{name:'Release directory PaymentService',exact:true}).click();
  await expect(page.locator('.pin-tray-toggle')).toHaveText('0 pins');
  await settled();
  const closed=await capture('structure-closed-again');
  expect([...closed.wrappers].sort()).toEqual([...before.wrappers].sort());
  expect(closed.nodes.filter(n=>n.ring)).toHaveLength(0);
  // Start the separately recorded journey from a fresh root address; Close preserves camera position.
  await page.goto('http://localhost:8915/samples/estate/?view=local&mode=3d&layout=structure');
  await settled();
  await page.locator('.force-graph-label').filter({hasText:/^PaymentService ·/}).click();
  await settled();
  await switchTo('2D');await switchTo('3D');
  await page.getByRole('button',{name:'Connections',exact:true}).click();await settled();
  const ending=await capture('recording-ending');
  for(const name of ['Hub','Gateway']){
    const target=ending.labels.find(l=>l.text.startsWith(name+' ·'));
    await page.locator(`.force-graph-label[data-node-id="${target.id}"]`).hover();
    await page.waitForTimeout(250);
    await page.screenshot({path:`${out}/hover-${name}.png`});
  }
  await page.mouse.move(300,900);
  for(const name of ['Hub','Gateway']){
    const label=page.locator('.force-graph-label').filter({hasText:new RegExp('^'+name+' ·')});
    await label.click();await settled();await capture(`connections-${name}-open`);
    const chip=page.locator('.force-graph-label').filter({hasText:new RegExp('^'+name+'$')});
    await expect(chip).toHaveCount(1);await chip.click();await settled();
    const after=await capture(`connections-${name}-rewrapped`);
    expect(after.wrappers).toContain(ending.labels.find(l=>l.text.startsWith(name+' ·')).id);
  }
}finally{
  fs.writeFileSync(`${out}/replay.json`,JSON.stringify({errors,readings},null,2)+'\n');
  await browser.close();
}
