import http from 'node:http';
import fs from 'node:fs';
const oldClient=fs.readFileSync(new URL('./baseline-index.js',import.meta.url));
http.createServer((request,response)=>{
 if(new URL(request.url,'http://localhost:8917').pathname==='/samples/estate/static/index.js'){
  response.writeHead(200,{'content-type':'text/javascript','cache-control':'no-store'});response.end(oldClient);return;
 }
 const upstream=http.get({hostname:'localhost',port:8915,path:request.url,headers:request.headers},res=>{response.writeHead(res.statusCode,res.headers);res.pipe(response);});
 upstream.on('error',error=>{response.writeHead(502);response.end(String(error));});
}).listen(8917,'127.0.0.1');
