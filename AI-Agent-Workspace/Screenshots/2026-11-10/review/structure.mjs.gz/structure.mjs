import fs from 'node:fs';
import { chromium, expect } from '@playwright/test';
import pictures from '../../../tests/e2e/still-picture.ts';

const out='AI-Agent-Workspace/Screenshots/2026-11-10/review';
const browser=await chromium.launch({headless:true});
const context=await browser.newContext({viewport:{width:1440,height:960},deviceScaleFactor:1,
  recordVideo:{dir:'AI-Agent-Workspace/tmp/2026-11-10-review/video',size:{width:1440,height:960}}});
const page=await context.newPage(), video=page.video(), errors=[], frames=[];
page.on('pageerror',e=>errors.push(String(e)));
const capture=async(name,start)=>{
  await page.screenshot({path:`${out}/${name}.png`});
  const read=await page.evaluate(()=>({url:location.href,viewport:[innerWidth,innerHeight],
    busy:document.querySelector('#graph-svg')?.getAttribute('aria-busy'),
    labels:[...document.querySelectorAll('.force-graph-label')].filter(e=>!e.hidden).map(e=>({text:e.textContent,id:e.dataset.nodeId,box:{x:e.getBoundingClientRect().x,y:e.getBoundingClientRect().y}})),
    footer:document.querySelector('#stats')?.textContent}));
  frames.push({name,elapsed:start?Date.now()-start:null,...read});
  console.log(JSON.stringify({name,elapsed:frames.at(-1).elapsed,busy:read.busy,labels:read.labels.map(l=>l.text)}));
};
try {
  await page.goto('http://localhost:8900/samples/estate/?view=local&mode=3d&layout=structure');
  await expect(page.locator('#graph-svg')).toHaveAttribute('aria-busy','false',{timeout:60000});
  await capture('structure-closed');
  const group=page.locator('.force-graph-label').filter({hasText:/^PaymentService ·/});
  await expect(group).toHaveCount(1);
  const start=Date.now();
  await group.click();
  for(const [i,delay] of [0,150,300,600].entries()){
    if(delay)await page.waitForTimeout(delay);
    await capture(`structure-opening-${i}`,start);
  }
  await expect(page.locator('#graph-svg')).toHaveAttribute('aria-busy','false',{timeout:60000});
  await page.mouse.move(300,900);
  await capture('structure-open',start);
  await page.getByRole('button',{name:'2D',exact:true}).click();
  await pictures.localMapSettled(page,60000);
  await capture('structure-to-2d');
  await page.getByRole('button',{name:'3D',exact:true}).click();
  await expect(page.locator('#graph-svg')).toHaveAttribute('aria-busy','false',{timeout:60000});
  await capture('structure-return');
  await page.getByRole('button',{name:'Connections',exact:true}).click();
  await expect(page.locator('#graph-svg')).toHaveAttribute('aria-busy','false',{timeout:60000});
  await capture('connections');
  await context.close();
  fs.copyFileSync(await video.path(),`${out}/structure-journey.webm`);
} finally {
  fs.writeFileSync(`${out}/structure.json`,JSON.stringify({clock:'normal',settings:'fresh context, default Skin/one hop',errors,frames},null,2)+'\n');
  await browser.close();
}
