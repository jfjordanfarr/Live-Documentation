import fs from 'node:fs';
import crypto from 'node:crypto';
import { chromium } from '@playwright/test';
import state from '../../../packages/explorer/src/client/persistence/compressed-url-state.ts';
import pictures from '../../../tests/e2e/still-picture.ts';

const out = 'AI-Agent-Workspace/Screenshots/2026-11-10/review';
fs.mkdirSync(out, { recursive: true });
const browser = await chromium.launch({ headless: true });
const reports = [];
try {
  for (const subject of [
    { name: 'main', base: 'http://localhost:8900/', file: 'packages/explorer/src/client/views/symbolAnchors.ts' },
    { name: 'estate', base: 'http://localhost:8900/samples/estate/', file: 'PaymentService/PaymentService.cs' }
  ]) {
    const context = await browser.newContext({ viewport: { width: 1440, height: 960 }, deviceScaleFactor: 1,
      recordVideo: { dir: 'AI-Agent-Workspace/tmp/2026-11-10-review/video', size: { width: 1440, height: 960 } } });
    const page = await context.newPage();
    const video = page.video();
    const errors = [];
    page.on('pageerror', e => errors.push(String(e)));
    const snapshot = { ...state.DEFAULT_SNAPSHOT, selectedNodeId: subject.file,
      pinSet: { entries: [{ nodeId: subject.file, symbol: '*' }] } };
    const startUrl = subject.base + '?s=' + encodeURIComponent(state.compressSnapshot(snapshot));
    await page.goto(startUrl);
    await pictures.localMapSettled(page, 60000);
    const asset = await (await page.request.get(subject.base + 'static/index.js')).body();
    const readings = [];
    const read = () => page.evaluate(file => {
      const map = document.querySelector('#map-container');
      const card = [...document.querySelectorAll('.node-card')].find(c => c.dataset.id === file);
      const title = card?.querySelector('.local-file-name-held');
      const box = card?.getBoundingClientRect();
      return { band: map?.dataset.lod, step: map?.dataset.step, camera: map?.dataset.camera,
        search: map?.querySelector('.local-placed')?.dataset.searchStatus,
        titleLines: title?.getAttribute(`data-lines-${map?.dataset.lod}-${map?.dataset.step}`),
        card: box ? { x: box.x, y: box.y, width: box.width, height: box.height } : null,
        viewport: [innerWidth, innerHeight], url: location.href };
    }, subject.file);
    const capture = async name => {
      const observation = { name, ...await read() };
      await page.screenshot({ path: `${out}/${subject.name}-${name}.png` });
      readings.push(observation);
      console.log(JSON.stringify({ subject: subject.name, ...observation, url: undefined }));
    };
    await page.mouse.move(300, 900);
    await capture('reading');
    if (subject.name === 'main') {
      await page.getByRole('button', { name: 'Fold symbolAnchors.ts', exact: true }).click();
      await page.mouse.move(300, 900);
      await capture('folded');
      const readOne = page.getByRole('button', { name: 'Read normalizeSymbolIdentifier in symbolAnchors.ts', exact: true });
      await readOne.click();
      await page.mouse.move(300, 900);
      await capture('subset');
    }
    for (let press = 1; press <= 8; press++) {
      await page.getByRole('button', { name: 'Zoom Out', exact: true }).click();
      await page.waitForTimeout(400);
      if ([2, 3, 4, 5, 7, 8].includes(press)) await capture(`out-${press}`);
      else readings.push({ name: `out-${press}`, ...await read() });
    }
    for (let press = 8; press > 0; press--) {
      await page.getByRole('button', { name: 'Zoom In', exact: true }).click();
      await page.waitForTimeout(400);
    }
    await capture('returned');
    const report = { subject, startUrl, viewport: [1440, 960], clock: 'normal',
      search: 'fresh context, normal defaults; initial search allowed to finish',
      assetSha256: crypto.createHash('sha256').update(asset).digest('hex'), errors, readings };
    reports.push(report);
    fs.writeFileSync(`${out}/${subject.name}.json`, JSON.stringify(report, null, 2) + '\n');
    await context.close();
    fs.copyFileSync(await video.path(), `${out}/${subject.name}-journey.webm`);
  }
} finally {
  await browser.close();
  fs.writeFileSync(`${out}/review.json`, JSON.stringify(reports, null, 2) + '\n');
}
