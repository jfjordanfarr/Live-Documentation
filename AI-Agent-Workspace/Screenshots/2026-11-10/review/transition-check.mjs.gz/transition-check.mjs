import fs from 'node:fs';
import { chromium, expect } from '@playwright/test';
import pictures from '../../../tests/e2e/still-picture.ts';
const out='AI-Agent-Workspace/Screenshots/2026-11-10/review';
const browser=await chromium.launch({headless:true});
const context=await browser.newContext({viewport:{width:1440,height:960},deviceScaleFactor:1,
  recordVideo:{dir:'AI-Agent-Workspace/tmp/2026-11-10-review/video',size:{width:1440,height:960}}});
const page=await context.newPage(),video=page.video(),errors=[],observations=[];
page.on('pageerror',e=>errors.push(String(e)));
const capture=async name=>{
  await page.screenshot({path:`${out}/${name}.png`});
  observations.push({name,url:page.url(),transitionCount:await page.locator('.perspective-transition').count(),
    cards:await page.locator('.node-card').evaluateAll(es=>es.map(e=>e.dataset.id)),
    labels:await page.locator('.force-graph-label').evaluateAll(es=>es.filter(e=>!e.hidden).map(e=>e.textContent))});
  console.log(name);
};
const switchTo=async name=>{
  const begun=page.locator('.perspective-transition').waitFor({state:'visible',timeout:30000});
  await page.getByRole('button',{name,exact:true}).click();
  await begun;
  await expect(page.locator('.perspective-transition')).toHaveCount(0,{timeout:60000});
};
try{
  await page.goto('http://localhost:8900/samples/estate/?view=local&mode=3d&layout=structure');
  await expect(page.locator('#graph-svg')).toHaveAttribute('aria-busy','false',{timeout:60000});
  await page.locator('.force-graph-label').filter({hasText:/^PaymentService ·/}).click();
  await expect(page.locator('#graph-svg')).toHaveAttribute('aria-busy','false',{timeout:60000});
  await page.mouse.move(300,900);
  await capture('transition-source');
  await switchTo('2D');
  await pictures.localMapSettled(page,60000);
  await capture('structure-to-2d-settled');
  await page.waitForTimeout(1500);
  await capture('structure-to-2d-later');
  await switchTo('3D');
  await expect(page.locator('#graph-svg')).toHaveAttribute('aria-busy','false',{timeout:60000});
  await capture('structure-return-settled');
  await page.getByRole('button',{name:'Connections',exact:true}).click();
  await expect(page.locator('#graph-svg')).toHaveAttribute('aria-busy','false',{timeout:60000});
  await page.waitForTimeout(500);
  await capture('connections-settled');
  await context.close();
  fs.copyFileSync(await video.path(),`${out}/transition-journey.webm`);
}finally{
  fs.writeFileSync(`${out}/transition.json`,JSON.stringify({clock:'normal',wait:'transition visible then removed, followed by destination settling',errors,observations},null,2)+'\n');
  await browser.close();
}
