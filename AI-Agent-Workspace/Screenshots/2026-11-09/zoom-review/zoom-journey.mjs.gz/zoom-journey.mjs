import fs from 'node:fs';
import crypto from 'node:crypto';
import { chromium, expect } from '@playwright/test';
import state from '../../../packages/explorer/src/client/persistence/compressed-url-state.ts';
import pictures from '../../../tests/e2e/still-picture.ts';
const out='AI-Agent-Workspace/Screenshots/2026-11-09/zoom-review';
fs.mkdirSync(out,{recursive:true});
const browser=await chromium.launch({headless:true});
const reports=[];
try {
  for(const subject of [
    {name:'repository',base:'http://localhost:8900/',file:'packages/explorer/src/client/views/symbolAnchors.ts'},
    {name:'estate',base:'http://localhost:8900/samples/estate/',file:'PaymentService/PaymentService.cs'}
  ]) {
    const context=await browser.newContext({viewport:{width:1440,height:960},deviceScaleFactor:1,recordVideo:{dir:'AI-Agent-Workspace/tmp/2026-11-09-zoom-review/video',size:{width:1440,height:960}}});
    const page=await context.newPage(),video=page.video(),errors=[];
    page.on('pageerror',e=>errors.push(String(e)));
    const snapshot={...state.DEFAULT_SNAPSHOT,selectedNodeId:subject.file,pinSet:{entries:[{nodeId:subject.file,symbol:'*'}]}};
    await page.goto(subject.base+'?s='+encodeURIComponent(state.compressSnapshot(snapshot)));
    await pictures.localMapSettled(page,60000);
    const asset=await (await page.request.get(subject.base+'static/index.js')).body();
    const readings=[];
    const read=()=>page.evaluate(file=>{
      const map=document.querySelector('#map-container'),root=map.querySelector('.local-placed');
      const drawn=e=>{if(!e)return null;const box=e.getBoundingClientRect();let scale=1,opacity=1,visible=box.width>0&&box.height>0;for(let a=e;a;a=a.parentElement){const s=getComputedStyle(a);if(s.display==='none'||s.visibility==='hidden')visible=false;opacity*=Number(s.opacity);if(s.transform!=='none'){const m=new DOMMatrixReadOnly(s.transform);scale*=Math.hypot(m.a,m.b);}}return {text:e.textContent?.trim(),visible:visible&&opacity>.01,fontPixels:parseFloat(getComputedStyle(e).fontSize)*scale,box:{x:box.x,y:box.y,w:box.width,h:box.height}};};
      const cards=[...document.querySelectorAll('.node-card')].map(card=>{
        const title=card.querySelector('.local-file-name-held');
        const label=card.querySelector('.symbol-row .symbol-label');
        const internals=card.querySelector('.symbol-row.internal .symbol-label, .symbol-row[data-symbol="__internals__"] .symbol-label');
        return {id:card.getAttribute('data-id'),box:drawn(card)?.box,titleLines:title?.getAttribute(`data-lines-${map.dataset.lod}-${map.dataset.step}`),heldTitle:drawn(title),publicName:drawn(label),internals:drawn(internals)};
      });
      return {step:map.dataset.step,band:map.dataset.lod,camera:map.dataset.camera??'',moving:root?.dataset.moving??'',search:root?.dataset.searchStatus,subject:cards.find(c=>c.id===file),cards};
    },subject.file);
    const capture=async(direction,press)=>{const r=await read();const filename=`${subject.name}-${direction}-${String(press).padStart(2,'0')}.png`;await page.screenshot({path:out+'/'+filename});readings.push({direction,press,filename,...r});console.log(JSON.stringify({subject:subject.name,direction,press,step:r.step,band:r.band,title:r.subject?.titleLines,publicFont:r.subject?.publicName?.fontPixels,search:r.search}));};
    await capture('out',0);
    for(let press=1;press<=10;press++){await page.getByRole('button',{name:'Zoom Out',exact:true}).click();await page.waitForTimeout(350);await capture('out',press);}
    for(let press=9;press>=0;press--){await page.getByRole('button',{name:'Zoom In',exact:true}).click();await page.waitForTimeout(350);if([7,5,4,2,1,0].includes(press))await capture('back',press);}
    const decoded=state.decompressSnapshot(new URL(page.url()).searchParams.get('s'));
    expect(decoded.pinSet.entries).toEqual(snapshot.pinSet.entries);
    const report={subject,viewport:[1440,960],clock:'normal',search:'normal default; initial settling awaited',assetSha256:crypto.createHash('sha256').update(asset).digest('hex'),url:page.url(),errors,readings};
    reports.push(report);fs.writeFileSync(out+'/'+subject.name+'-readings.json',JSON.stringify(report,null,2)+'\n');
    await context.close();fs.copyFileSync(await video.path(),out+'/'+subject.name+'-roundtrip.webm');
  }
} finally {await browser.close();}
console.log(JSON.stringify({complete:true,journeys:reports.length,errors:reports.flatMap(r=>r.errors)}));
