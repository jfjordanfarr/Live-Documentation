import fs from 'node:fs';
import { chromium, expect } from '@playwright/test';
import snapshots from '../../../packages/explorer/src/client/persistence/compressed-url-state.ts';
import pictures from '../../../tests/e2e/still-picture.ts';
const out='AI-Agent-Workspace/Screenshots/2026-11-09/zoom-review';
const browser=await chromium.launch({headless:true});
const errors=[], readings=[];
const context=await browser.newContext({viewport:{width:1440,height:960},deviceScaleFactor:1,recordVideo:{dir:'AI-Agent-Workspace/tmp/2026-11-09-zoom-review/video',size:{width:1440,height:960}}});
const page=await context.newPage(),video=page.video();
page.on('pageerror',error=>errors.push(String(error)));
const address=(base,nodeId,extra={})=>base+'?s='+encodeURIComponent(snapshots.compressSnapshot({...snapshots.DEFAULT_SNAPSHOT,selectedNodeId:nodeId,pinSet:{entries:nodeId?[{nodeId,symbol:'*'}]:[]},...extra}));
const shot=async name=>{await page.screenshot({path:out+'/'+name+'.png'});};
try {
  const file='packages/explorer/src/client/reading-state.ts';
  await page.goto(address('http://localhost:8912/',file));
  await pictures.localMapSettled(page,60000);
  const card=page.locator(`.node-card[data-id="${file}"]`),book=card.locator('.local-file-read');
  const size=()=>card.evaluate(e=>({width:e.offsetWidth,height:e.offsetHeight}));
  const before=await size();
  await book.click();await expect(card.locator('.local-reading-purpose')).toHaveCSS('visibility','hidden');
  await shot('root-reading-none');
  await card.locator('.symbol-row[data-symbol="descriptionIsOpen"] .local-symbol-read').click();
  await expect(card.locator('.symbol-row[data-symbol="descriptionIsOpen"] .local-reading-slot')).toHaveCSS('visibility','visible');
  const shared=page.url(),after=await size();expect(after).toEqual(before);
  await shot('root-reading-subset');
  readings.push({kind:'reading',before,after,shared,choices:snapshots.decompressSnapshot(new URL(shared).searchParams.get('s')).reading});
  const recipient=await browser.newContext({viewport:{width:1440,height:960}}),other=await recipient.newPage();
  await other.goto(shared);await pictures.localMapSettled(other,60000);
  await expect(other.locator(`.node-card[data-id="${file}"] .local-reading-purpose`)).toHaveCSS('visibility','hidden');
  await expect(other.locator(`.node-card[data-id="${file}"] .symbol-row[data-symbol="descriptionIsOpen"] .local-reading-slot`)).toHaveCSS('visibility','visible');
  await recipient.close();
  await card.locator('.symbol-row[data-symbol="descriptionIsOpen"] .symbol-label').click();
  await expect(page.locator('#detail-panel')).toHaveAttribute('aria-hidden','false');
  await expect(page.locator('[data-reader-symbol="descriptionIsOpen"] > h4')).toBeInViewport();
  const next=page.locator('#detail-body a').filter({hasText:/^chooseReading$/}).first();
  await next.click();
  await expect(page.locator('[data-reader-symbol="chooseReading"] > h4')).toBeInViewport();
  await shot('root-symbol-reader');
  readings.push({kind:'reader',heading:await page.locator('[data-reader-symbol] > h4').textContent(),position:await page.locator('[data-reader-symbol] > h4').boundingBox()});
  await page.locator('#detail-close').click();

  // Normal wheel motion on the released main build, with no scene/clock intervention.
  const subject='PaymentService/PaymentService.cs';
  await page.goto(address('http://localhost:8900/samples/estate/',subject));
  await pictures.localMapSettled(page,60000);
  await page.mouse.move(850,470);
  await page.evaluate(()=>{const map=document.querySelector('#map-container'),viewport=document.querySelector('#map-viewport');window.zoomReadings=[];let until=performance.now()+6500;const record=()=>{const card=document.querySelector('.node-card[data-id="PaymentService/PaymentService.cs"]');const text=card?.querySelector('.symbol-row .symbol-label-text');let scale=1;for(let a=text;a;a=a.parentElement){const style=getComputedStyle(a);if(style.transform!=='none'){const m=new DOMMatrixReadOnly(style.transform);scale*=Math.hypot(m.c,m.d);}}window.zoomReadings.push({at:performance.now(),step:map.dataset.step,band:map.dataset.lod,k:new DOMMatrixReadOnly(getComputedStyle(viewport).transform).a,font:text?parseFloat(getComputedStyle(text).fontSize)*scale:null,title:card?.querySelector('.local-file-name-held')?.getAttribute(`data-lines-${map.dataset.lod}-${map.dataset.step}`)});if(performance.now()<until)requestAnimationFrame(record);};record();});
  await page.mouse.wheel(0,360);await page.waitForTimeout(900);await shot('root-wheel-out-first');
  await page.mouse.wheel(0,360);await page.waitForTimeout(900);await shot('root-wheel-out-second');
  await page.mouse.wheel(0,-720);await page.waitForTimeout(1200);await shot('root-wheel-return');
  readings.push({kind:'wheel',frames:await page.evaluate(()=>window.zoomReadings)});

  await page.goto('http://localhost:8900/samples/estate/?view=local&mode=3d&layout=structure');
  await expect(page.locator('#graph-svg')).toHaveAttribute('aria-busy','false',{timeout:30000});
  await shot('root-pop-before');
  const group=page.locator('.force-graph-label').filter({hasText:/^PaymentService ·/});
  expect(await group.count()).toBe(1);
  const start=Date.now();await group.click();
  const pop=[];
  for(const delay of [0,100,200,400,800]){if(delay)await page.waitForTimeout(delay);const name='root-pop-'+pop.length;await shot(name);pop.push({elapsed:Date.now()-start,image:name+'.png',busy:await page.locator('#graph-svg').getAttribute('aria-busy'),labels:await page.locator('.force-graph-label').evaluateAll(es=>es.filter(e=>!e.hidden).map(e=>({text:e.textContent,id:e.dataset.nodeId,kind:e.dataset.kind,x:e.getBoundingClientRect().x,y:e.getBoundingClientRect().y})))});}
  await expect(page.locator('#graph-svg')).toHaveAttribute('aria-busy','false',{timeout:60000});
  await shot('root-pop-settled');
  readings.push({kind:'directory-pop',elapsedToSettled:Date.now()-start,frames:pop,url:page.url()});
  fs.writeFileSync(out+'/root-review.json',JSON.stringify({viewport:[1440,960],clock:'normal',readingCandidate:'8912',zoomAndPopMain:'8900',errors,readings},null,2)+'\n');
  await context.close();fs.copyFileSync(await video.path(),out+'/root-review.webm');
  console.log(JSON.stringify({complete:true,errors,readingSize:before,readingChoiceCount:readings[0].choices?.length,popElapsed:readings.at(-1).elapsedToSettled}));
} finally {await browser.close();}
