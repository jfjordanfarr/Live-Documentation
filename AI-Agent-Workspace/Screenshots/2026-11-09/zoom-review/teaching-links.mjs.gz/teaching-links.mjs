import fs from 'node:fs';
import {chromium,expect} from '@playwright/test';
import snapshots from '../../../packages/explorer/src/client/persistence/compressed-url-state.ts';
import pictures from '../../../tests/e2e/still-picture.ts';
const file='AI-Agent-Workspace/Probes/2026-11-09/reading-verification/teaching-links.json';
const links=JSON.parse(fs.readFileSync(file,'utf8'));
const out='AI-Agent-Workspace/Screenshots/2026-11-09/zoom-review';
const browser=await chromium.launch({headless:true}),results=[];
try {
 for(const [name,url] of Object.entries(links.links)){
  const context=await browser.newContext({viewport:{width:1440,height:960},deviceScaleFactor:1});
  const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(String(e)));
  try{
   await page.goto(url);
   // Full reading deliberately pauses the map search; its ready heading is this link's first visible result.
   if(name==='textRefresh')await expect(page.locator('[data-reader-symbol="refreshReadingPresentation"] > h4')).toBeInViewport();
   else await pictures.localMapSettled(page,60000);
   const state=snapshots.decompressSnapshot(new URL(page.url()).searchParams.get('s'));
   expect(state.pinSet.entries.map(p=>[p.nodeId,p.symbol])).toEqual([[state.selectedNodeId,'*']]);
   const subject=page.locator(`.node-card[data-id="${state.selectedNodeId}"]`);
   if(name==='controls')await expect(subject.locator('.local-file-read')).toHaveCount(1);
   if(name==='subset'){
    await expect(subject.locator('.local-reading-purpose')).toHaveCSS('visibility','hidden');
    await expect(subject.locator('.symbol-row[data-symbol="descriptionIsOpen"] .local-reading-slot')).toBeVisible();
    await expect(subject.locator('.symbol-row[data-symbol="chooseReading"] .local-reading-slot')).toBeHidden();
   }
   if(name==='none')await expect(subject.locator('.local-reading-slot:visible')).toHaveCount(0);
   let heading=null;
   if(name==='textRefresh'){
    const target=page.locator('[data-reader-symbol="refreshReadingPresentation"] > h4');
    await expect(target).toBeInViewport();heading=await target.boundingBox();
    const body=await page.locator('#detail-body').boundingBox();expect(heading.y).toBeGreaterThanOrEqual(body.y);
   }
   expect(errors).toEqual([]);await page.screenshot({path:`${out}/teaching-${name}.png`});
   let background=null;
   if(name==='textRefresh'){
    const read=()=>page.locator('#map-container .local-placed').evaluate(e=>({status:e.dataset.searchStatus,tried:e.dataset.searchTried}));
    const whileReading=await read();await page.locator('#detail-close').click();
    await pictures.localMapSettled(page,60000);const afterClose=await read();
    background={whileReading,afterClose};await page.screenshot({path:`${out}/teaching-${name}-closed.png`});
   }
   results.push({name,url,pageUrl:page.url(),pinSet:state.pinSet,reading:state.reading,inspection:state.inspection,heading,background,errors});
  }finally{await context.close();}
 }
 links.verified='Fresh recipient browser contexts on main8900 after the final gate: each explicit pin and intended reading/inspection state checked, screenshots saved for separate root review.';
 links.browserResults=results;fs.writeFileSync(file,JSON.stringify(links,null,2)+'\n');console.log(JSON.stringify({completed:results.length,errors:results.flatMap(r=>r.errors)}));
}finally{await browser.close();}
